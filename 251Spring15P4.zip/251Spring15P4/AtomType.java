
public enum AtomType {
	OPERATOR, OPERAND;
}
